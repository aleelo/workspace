<div id="bank_register_reconcile_info_div" class="mbot25"></div>
<div class="mbot25 text-center"><h4><?php echo _l('cash_transactions_recorded_in_revenue_and_expenses'); ?></h4></div>

<table class="table table-banking-registers">
  <thead>
    
  </thead>
  <tbody>
    
  </tbody>
</table>

<?php require 'plugins/Accounting/assets/js/banking/banking_register_js.php';?>
