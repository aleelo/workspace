
<div class="card">
    <div class="clearfix">
      <table id="expenses-table" class="display table-expenses" cellspacing="0" width="100%">            
    </table>
    </div>
</div>

<?php require 'plugins/Accounting/assets/js/transaction/expenses_js.php';?>
